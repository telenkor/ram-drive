//
//  SMSTableDialogBuilder.h
//  SMSTableDialogBuilder
//
//  Created by Shane Stanley on 11/01/2016.
//  Copyright © 2016 Shane Stanley. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <SMSTableDialogBuilder/SMSTableDialogController.h>

//! Project version number for SMSTableDialogBuilder.
FOUNDATION_EXPORT double SMSTableDialogBuilderVersionNumber;

//! Project version string for SMSTableDialogBuilder.
FOUNDATION_EXPORT const unsigned char SMSTableDialogBuilderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SMSTableDialogBuilder/PublicHeader.h>


